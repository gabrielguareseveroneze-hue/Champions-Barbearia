import { motion, useReducedMotion } from 'motion/react';
import { ArrowDownRight, MessageCircle } from 'lucide-react';
import { HERO_IMAGE, buildWhatsAppUrl } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function HeroSection() {
  const prefersReduced = useReducedMotion();
  const whatsappHref = buildWhatsAppUrl(
    'Olá! Vi o site da Champions Barbearia e gostaria de agendar um horário.'
  );

  return (
    <section
      id="inicio"
      className="relative pt-24 pb-12 sm:pt-28 sm:pb-16 lg:pt-32 lg:pb-20 min-h-[calc(100svh-4.5rem)] flex items-center"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left Editorial Column */}
          <motion.div
            initial={prefersReduced ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex flex-col justify-center py-2 lg:py-8"
          >
            <p className="text-xs sm:text-sm font-medium tracking-[0.18em] uppercase text-ink-muted mb-5">
              Araguaína · Jardim dos Ipês 2
            </p>

            <h1 className="font-display font-semibold tracking-tight leading-[1.03] text-[clamp(2.85rem,5.4vw,4.75rem)] text-ink mb-6">
              Estilo &amp;{' '}
              <span className="text-navy-gradient italic font-semibold">Tradição</span>
            </h1>

            <p className="text-base sm:text-lg text-ink-muted leading-relaxed max-w-[38ch] mb-10">
              Precisão no corte, barba impecável e ambiente reservado para quem exige padrão de
              campeão.
            </p>

            <div className="flex flex-wrap items-center gap-6">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm sm:text-base font-semibold text-ink bg-brand hover:bg-brand-hover rounded-lg transition-all duration-200 hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-bright"
              >
                <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>Conversar no WhatsApp</span>
              </a>

              <a
                href="#servicos"
                className="inline-flex items-center gap-1.5 py-2 text-sm font-medium text-ink-muted hover:text-ink transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-brand-bright"
              >
                <span>Ver serviços</span>
                <ArrowDownRight className="w-4 h-4" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Right Architectural Media Column */}
          <motion.div
            initial={prefersReduced ? false : { opacity: 0, scale: 0.985 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex"
          >
            <div className="relative w-full aspect-[4/3] sm:aspect-[16/11] lg:aspect-auto lg:min-h-[540px] rounded-xl overflow-hidden border border-hairline bg-surface">
              <ResilientImage
                src={HERO_IMAGE.src}
                alt={HERO_IMAGE.alt}
                loading="eager"
                fetchPriority="high"
                className="w-full h-full object-cover object-center"
              />
              {/* Measured atmospheric scrim for seamless edge integration */}
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-canvas/85 via-canvas/15 to-transparent pointer-events-none"
              />
              <div className="absolute bottom-5 left-5 right-5 sm:bottom-7 sm:left-7 sm:right-7 flex items-end justify-between gap-4">
                <div>
                  <p className="font-display text-lg sm:text-xl font-medium text-ink">
                    Champions Barbearia
                  </p>
                  <p className="text-xs sm:text-sm text-ink-muted">
                    Av. Cônego João Lima · Araguaína - TO
                  </p>
                </div>
                <a
                  href="#contato"
                  className="hidden sm:inline-flex items-center gap-1.5 text-xs font-medium text-ink/90 hover:text-ink border border-hairline-strong bg-canvas/70 backdrop-blur-sm px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Agendar horário</span>
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
