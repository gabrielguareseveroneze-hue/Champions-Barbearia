import { useState, FormEvent } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import {
  MapPin,
  Phone,
  MessageCircle,
  ExternalLink,
  Copy,
  Check,
  ArrowUpRight,
} from 'lucide-react';
import {
  ADDRESS_FULL,
  MAPS_URL,
  PHONE_DISPLAY,
  SERVICES,
  buildWhatsAppUrl,
} from '../data/barbershop';

const BOOKING_OPTIONS = [
  ...SERVICES.map((s) => `${s.name} (${s.price})`),
  'Combo Corte + Barba',
];

const DAY_OPTIONS = ['Hoje', 'Amanhã', 'Esta semana', 'Sábado'];
const PERIOD_OPTIONS = ['Manhã', 'Tarde', 'Noite'];

export function ContactBookingSection() {
  const prefersReduced = useReducedMotion();

  const [selectedService, setSelectedService] = useState(BOOKING_OPTIONS[0]);
  const [selectedDay, setSelectedDay] = useState(DAY_OPTIONS[0]);
  const [selectedPeriod, setSelectedPeriod] = useState(PERIOD_OPTIONS[1]);
  const [clientName, setClientName] = useState('');
  const [notes, setNotes] = useState('');
  const [nameError, setNameError] = useState('');
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [generatedUrl, setGeneratedUrl] = useState<string | null>(null);

  const directWhatsAppUrl = buildWhatsAppUrl(
    'Olá! Gostaria de falar com a equipe da Champions Barbearia.'
  );

  const handleCopyAddress = async () => {
    try {
      await navigator.clipboard.writeText(ADDRESS_FULL);
      setCopiedAddress(true);
      setTimeout(() => setCopiedAddress(false), 2500);
    } catch {
      setCopiedAddress(false);
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmedName = clientName.trim();

    if (trimmedName.length < 2) {
      setNameError('Informe seu nome para preparar o agendamento.');
      return;
    }

    setNameError('');
    const lines = [
      `Olá, Champions Barbearia! Meu nome é *${trimmedName}*.`,
      `Gostaria de agendar: *${selectedService}*`,
      `Preferência: *${selectedDay}* · período da *${selectedPeriod}*`,
    ];

    if (notes.trim()) {
      lines.push(`Observações: ${notes.trim()}`);
    }

    const url = buildWhatsAppUrl(lines.join('\n'));
    setGeneratedUrl(url);

    // Safe external navigation without window.open
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.target = '_blank';
    anchor.rel = 'noopener noreferrer';
    anchor.click();
  };

  return (
    <section id="contato" className="py-24 sm:py-32 border-t border-hairline">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Location & Direct WhatsApp */}
          <motion.div
            initial={prefersReduced ? false : { opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 space-y-10"
          >
            <div>
              <p className="text-xs font-medium tracking-[0.18em] uppercase text-brand-bright mb-4">
                Agendamento &amp; Localização
              </p>
              <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-ink mb-5 leading-[1.08]">
                Reserve sua cadeira.
              </h2>
              <p className="text-base text-ink-muted leading-relaxed max-w-[38ch]">
                Atendimento direto pelo WhatsApp para confirmar o melhor horário com nossa equipe.
              </p>
            </div>

            <div className="divide-y divide-hairline border-y border-hairline">
              <div className="py-6 space-y-3">
                <div className="flex items-center gap-2.5 text-xs font-medium uppercase tracking-[0.14em] text-ink-subtle">
                  <MapPin className="w-4 h-4 text-brand-bright shrink-0" aria-hidden="true" />
                  <span>Endereço</span>
                </div>
                <p className="text-sm sm:text-base text-ink leading-relaxed">
                  {ADDRESS_FULL}
                </p>
                <div className="flex flex-wrap items-center gap-4 pt-1">
                  <a
                    href={MAPS_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-medium text-brand-bright hover:text-ink transition-colors"
                  >
                    <span>Ver no Google Maps</span>
                    <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                  </a>

                  <button
                    type="button"
                    onClick={handleCopyAddress}
                    className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-medium text-ink-muted hover:text-ink transition-colors"
                  >
                    {copiedAddress ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-success" aria-hidden="true" />
                        <span className="text-success">Endereço copiado</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Copiar endereço</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              <div className="py-6 space-y-2">
                <div className="flex items-center gap-2.5 text-xs font-medium uppercase tracking-[0.14em] text-ink-subtle">
                  <Phone className="w-4 h-4 text-brand-bright shrink-0" aria-hidden="true" />
                  <span>Telefone / WhatsApp</span>
                </div>
                <a
                  href={directWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block font-display text-2xl font-semibold tabular-nums text-ink hover:text-brand-bright transition-colors"
                >
                  {PHONE_DISPLAY}
                </a>
              </div>
            </div>

            <div>
              <a
                href={directWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-4 text-sm sm:text-base font-semibold text-ink bg-brand hover:bg-brand-hover rounded-lg transition-all duration-200 hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-bright"
              >
                <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>Conversar no WhatsApp</span>
              </a>
            </div>
          </motion.div>

          {/* Right Column: Interactive Online Booking Form */}
          <motion.div
            initial={prefersReduced ? false : { opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <form
              onSubmit={handleSubmit}
              noValidate
              className="bg-surface border border-hairline rounded-xl p-6 sm:p-10 space-y-7"
            >
              <div className="border-b border-hairline pb-5">
                <h3 className="font-display text-2xl sm:text-3xl font-semibold text-ink">
                  Agendamento Online
                </h3>
                <p className="text-sm text-ink-muted mt-1.5">
                  Escolha o serviço e envie sua preferência direto para o nosso WhatsApp.
                </p>
              </div>

              {/* Service Selector */}
              <fieldset className="space-y-3">
                <legend className="text-xs font-medium uppercase tracking-[0.14em] text-ink-muted">
                  Serviço desejado
                </legend>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {BOOKING_OPTIONS.map((option) => {
                    const active = selectedService === option;
                    return (
                      <button
                        key={option}
                        type="button"
                        onClick={() => setSelectedService(option)}
                        aria-pressed={active}
                        className={`px-4 py-3 rounded-lg text-left text-sm font-medium border transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-brand-bright ${
                          active
                            ? 'bg-brand border-brand-bright text-ink'
                            : 'bg-canvas/60 border-hairline text-ink-muted hover:text-ink hover:border-hairline-strong'
                        }`}
                      >
                        {option}
                      </button>
                    );
                  })}
                </div>
              </fieldset>

              {/* Day & Period Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <fieldset className="space-y-3">
                  <legend className="text-xs font-medium uppercase tracking-[0.14em] text-ink-muted">
                    Dia de preferência
                  </legend>
                  <div className="flex flex-wrap gap-2">
                    {DAY_OPTIONS.map((day) => {
                      const active = selectedDay === day;
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => setSelectedDay(day)}
                          aria-pressed={active}
                          className={`px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium border transition-colors duration-150 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-brand-bright ${
                            active
                              ? 'bg-brand border-brand-bright text-ink'
                              : 'bg-canvas/60 border-hairline text-ink-muted hover:text-ink'
                          }`}
                        >
                          {day}
                        </button>
                      );
                    })}
                  </div>
                </fieldset>

                <fieldset className="space-y-3">
                  <legend className="text-xs font-medium uppercase tracking-[0.14em] text-ink-muted">
                    Período
                  </legend>
                  <div className="flex flex-wrap gap-2">
                    {PERIOD_OPTIONS.map((period) => {
                      const active = selectedPeriod === period;
                      return (
                        <button
                          key={period}
                          type="button"
                          onClick={() => setSelectedPeriod(period)}
                          aria-pressed={active}
                          className={`px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium border transition-colors duration-150 whitespace-nowrap focus-visible:outline-2 focus-visible:outline-brand-bright ${
                            active
                              ? 'bg-brand border-brand-bright text-ink'
                              : 'bg-canvas/60 border-hairline text-ink-muted hover:text-ink'
                          }`}
                        >
                          {period}
                        </button>
                      );
                    })}
                  </div>
                </fieldset>
              </div>

              {/* Client Name */}
              <div className="space-y-2">
                <label
                  htmlFor="booking-name"
                  className="block text-xs font-medium uppercase tracking-[0.14em] text-ink-muted"
                >
                  Seu nome
                </label>
                <input
                  id="booking-name"
                  type="text"
                  required
                  value={clientName}
                  onChange={(e) => {
                    setClientName(e.target.value);
                    if (nameError) setNameError('');
                  }}
                  placeholder="Ex.: Lucas Almeida"
                  aria-invalid={Boolean(nameError)}
                  aria-describedby={nameError ? 'booking-name-error' : undefined}
                  className="w-full px-4 py-3 rounded-lg bg-canvas border border-hairline text-ink placeholder:text-ink-subtle text-sm sm:text-base focus:outline-none focus:border-brand-bright transition-colors"
                />
                {nameError && (
                  <p id="booking-name-error" role="alert" className="text-xs text-error">
                    {nameError}
                  </p>
                )}
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <label
                  htmlFor="booking-notes"
                  className="block text-xs font-medium uppercase tracking-[0.14em] text-ink-muted"
                >
                  Observações (opcional)
                </label>
                <input
                  id="booking-notes"
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex.: Preferência por degradê navalhado ou horário aproximado"
                  className="w-full px-4 py-3 rounded-lg bg-canvas border border-hairline text-ink placeholder:text-ink-subtle text-sm sm:text-base focus:outline-none focus:border-brand-bright transition-colors"
                />
              </div>

              <div className="pt-2 space-y-4">
                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-4 text-sm sm:text-base font-semibold text-ink bg-brand hover:bg-brand-hover rounded-lg transition-colors duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-bright cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>Confirmar no WhatsApp</span>
                </button>

                {generatedUrl && (
                  <div
                    role="status"
                    className="p-4 rounded-lg bg-canvas border border-hairline-strong flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <p className="text-xs sm:text-sm text-ink-muted">
                      Mensagem pronta para envio no WhatsApp.
                    </p>
                    <a
                      href={generatedUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-brand-bright hover:text-ink whitespace-nowrap shrink-0"
                    >
                      <span>Abrir conversa agora</span>
                      <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                    </a>
                  </div>
                )}
              </div>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
