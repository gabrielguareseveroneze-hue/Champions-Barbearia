import { ADDRESS_FULL, PHONE_DISPLAY, buildWhatsAppUrl } from '../data/barbershop';

export function Footer() {
  const whatsappUrl = buildWhatsAppUrl(
    'Olá! Gostaria de falar com a Champions Barbearia.'
  );

  return (
    <footer className="border-t border-hairline bg-surface/50 py-12 sm:py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 pb-10 border-b border-hairline">
          <div className="space-y-2 max-w-md">
            <a
              href="#inicio"
              className="font-display text-xl font-semibold tracking-tight text-ink inline-block"
            >
              Champions Barbearia
            </a>
            <p className="text-xs sm:text-sm text-ink-muted leading-relaxed">
              {ADDRESS_FULL}
            </p>
          </div>

          <nav
            aria-label="Links do rodapé"
            className="flex flex-wrap items-center gap-6 sm:gap-8 text-sm text-ink-muted"
          >
            <a href="#inicio" className="hover:text-ink transition-colors whitespace-nowrap">
              Início
            </a>
            <a href="#servicos" className="hover:text-ink transition-colors whitespace-nowrap">
              Serviços
            </a>
            <a href="#galeria" className="hover:text-ink transition-colors whitespace-nowrap">
              Galeria
            </a>
            <a href="#contato" className="hover:text-ink transition-colors whitespace-nowrap">
              Contato
            </a>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-brand-bright hover:text-ink font-medium transition-colors whitespace-nowrap tabular-nums"
            >
              {PHONE_DISPLAY}
            </a>
          </nav>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-ink-subtle">
          <p>© {new Date().getFullYear()} Champions Barbearia. Todos os direitos reservados.</p>
          <p>Araguaína · Tocantins</p>
        </div>
      </div>
    </footer>
  );
}
