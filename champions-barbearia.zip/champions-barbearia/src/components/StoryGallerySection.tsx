import { useState, useEffect, useCallback } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { ChevronLeft, ChevronRight, X, Expand } from 'lucide-react';
import { GALLERY_PHOTOS, STATS, STORY_IMAGE } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function StoryGallerySection() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const prefersReduced = useReducedMotion();

  const closeLightbox = useCallback(() => setLightboxIndex(null), []);

  const showPrev = useCallback(() => {
    setLightboxIndex((prev) =>
      prev === null ? null : (prev - 1 + GALLERY_PHOTOS.length) % GALLERY_PHOTOS.length
    );
  }, []);

  const showNext = useCallback(() => {
    setLightboxIndex((prev) =>
      prev === null ? null : (prev + 1) % GALLERY_PHOTOS.length
    );
  }, []);

  useEffect(() => {
    if (lightboxIndex === null) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') showPrev();
      if (e.key === 'ArrowRight') showNext();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [lightboxIndex, closeLightbox, showPrev, showNext]);

  const activePhoto = lightboxIndex !== null ? GALLERY_PHOTOS[lightboxIndex] : null;

  return (
    <section id="galeria" className="py-24 sm:py-32 border-t border-hairline bg-surface/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        {/* Part 1: Inverted Editorial Rhythm — Image Left, Story & Stats Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center mb-24 sm:mb-32">
          <motion.div
            initial={prefersReduced ? false : { opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="relative aspect-[4/5] sm:aspect-[5/4] lg:aspect-[4/5] rounded-xl overflow-hidden border border-hairline bg-surface">
              <ResilientImage
                src={STORY_IMAGE.src}
                alt={STORY_IMAGE.alt}
                loading="lazy"
                className="w-full h-full object-cover object-top"
              />
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-canvas/70 via-transparent to-transparent pointer-events-none"
              />
            </div>
          </motion.div>

          <motion.div
            initial={prefersReduced ? false : { opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.25 }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <p className="text-xs font-medium tracking-[0.18em] uppercase text-brand-bright mb-4">
              Sobre Nós
            </p>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-ink mb-6 leading-[1.1]">
              Tradição que se percebe no acabamento.
            </h2>
            <p className="text-base sm:text-lg text-ink-muted leading-relaxed max-w-[48ch] mb-12">
              Na Champions Barbearia, cada cadeira une técnica clássica, precisão contemporânea e
              atendimento próximo. Construímos um espaço reservado em Araguaína onde o cuidado
              masculino é levado a sério do início ao fim.
            </p>

            {/* Claim-to-Proof Adjacent Metrics Strip */}
            <div className="grid grid-cols-2 gap-x-8 gap-y-8 pt-8 border-t border-hairline">
              {STATS.map((stat) => (
                <div key={stat.label} className="space-y-1">
                  <p className="font-display text-3xl sm:text-4xl font-semibold tabular-nums text-ink">
                    {stat.value}
                  </p>
                  <p className="text-xs sm:text-sm text-ink-muted">{stat.label}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Part 2: Asymmetric Space & Craft Gallery */}
        <motion.div
          initial={prefersReduced ? false : { opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10 sm:mb-12"
        >
          <div>
            <p className="text-xs font-medium tracking-[0.18em] uppercase text-brand-bright mb-3">
              Nosso Espaço
            </p>
            <h3 className="font-display text-2xl sm:text-3xl lg:text-4xl font-semibold tracking-tight text-ink">
              Dentro da Champions
            </h3>
          </div>
          <p className="text-xs sm:text-sm text-ink-muted">
            Clique em qualquer registro para ampliar
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 sm:gap-6">
          {GALLERY_PHOTOS.map((photo, index) => (
            <motion.button
              key={photo.id}
              type="button"
              onClick={() => setLightboxIndex(index)}
              initial={prefersReduced ? false : { opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.15 }}
              transition={{
                duration: 0.5,
                delay: Math.min(index * 0.06, 0.24),
                ease: [0.16, 1, 0.3, 1],
              }}
              aria-label={`Ampliar foto: ${photo.caption}`}
              className={`group relative rounded-xl overflow-hidden border border-hairline bg-surface text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-bright ${photo.spanClass} ${photo.aspectClass}`}
            >
              <ResilientImage
                src={photo.src}
                alt={photo.alt}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
              />
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-canvas/85 via-canvas/10 to-transparent opacity-80 group-hover:opacity-95 transition-opacity duration-300"
              />
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between gap-3">
                <span className="text-xs sm:text-sm font-medium text-ink">
                  {photo.caption}
                </span>
                <span className="w-8 h-8 rounded-lg bg-canvas/70 border border-hairline flex items-center justify-center text-ink-muted group-hover:text-ink transition-colors shrink-0">
                  <Expand className="w-3.5 h-3.5" aria-hidden="true" />
                </span>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Accessible Lightbox Modal */}
      {activePhoto && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={activePhoto.caption}
          className="fixed inset-0 z-50 bg-canvas/95 backdrop-blur-md flex flex-col justify-between p-4 sm:p-8"
          onClick={closeLightbox}
        >
          <div
            className="flex items-center justify-between gap-4 max-w-6xl w-full mx-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <p className="text-sm font-medium text-ink">
              {activePhoto.caption}{' '}
              <span className="text-ink-subtle tabular-nums ml-2">
                {(lightboxIndex ?? 0) + 1} / {GALLERY_PHOTOS.length}
              </span>
            </p>
            <button
              type="button"
              onClick={closeLightbox}
              aria-label="Fechar visualização"
              className="w-10 h-10 rounded-lg border border-hairline bg-surface hover:bg-surface-elevated text-ink flex items-center justify-center transition-colors focus-visible:outline-2 focus-visible:outline-brand-bright"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>

          <div
            className="relative flex-1 flex items-center justify-center max-w-5xl w-full mx-auto my-4 min-h-0"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={activePhoto.src}
              alt={activePhoto.alt}
              referrerPolicy="no-referrer"
              className="max-h-full max-w-full object-contain rounded-lg border border-hairline"
            />
          </div>

          <div
            className="flex items-center justify-center gap-4 max-w-6xl w-full mx-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={showPrev}
              aria-label="Foto anterior"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-hairline bg-surface hover:bg-surface-elevated text-sm font-medium text-ink transition-colors focus-visible:outline-2 focus-visible:outline-brand-bright"
            >
              <ChevronLeft className="w-4 h-4" aria-hidden="true" />
              <span>Anterior</span>
            </button>
            <button
              type="button"
              onClick={showNext}
              aria-label="Próxima foto"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg border border-hairline bg-surface hover:bg-surface-elevated text-sm font-medium text-ink transition-colors focus-visible:outline-2 focus-visible:outline-brand-bright"
            >
              <span>Próxima</span>
              <ChevronRight className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
