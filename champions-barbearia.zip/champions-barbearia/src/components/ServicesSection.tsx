import { useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'motion/react';
import { ArrowUpRight, MessageCircle } from 'lucide-react';
import { SERVICES, buildWhatsAppUrl } from '../data/barbershop';
import { ResilientImage } from './ResilientImage';

export function ServicesSection() {
  const [activeId, setActiveId] = useState(SERVICES[0].id);
  const prefersReduced = useReducedMotion();

  const activeService = SERVICES.find((s) => s.id === activeId) ?? SERVICES[0];

  return (
    <section id="servicos" className="py-24 sm:py-32 border-t border-hairline">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        {/* Section Header */}
        <motion.div
          initial={prefersReduced ? false : { opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14 sm:mb-20"
        >
          <div>
            <p className="text-xs font-medium tracking-[0.18em] uppercase text-brand-bright mb-3">
              Menu de Cuidados
            </p>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-ink">
              Nossos Serviços
            </h2>
          </div>
          <p className="text-sm sm:text-base text-ink-muted max-w-[36ch] leading-relaxed">
            Técnica apurada, produtos selecionados e tempo dedicado em cada atendimento.
          </p>
        </motion.div>

        {/* Asymmetric Editorial Showcase: Interactive List + Live Portrait */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-stretch">
          {/* Left: Numbered Service Rows */}
          <div className="lg:col-span-6 flex flex-col justify-between divide-y divide-hairline border-y border-hairline">
            {SERVICES.map((service) => {
              const isActive = service.id === activeService.id;
              const serviceWaUrl = buildWhatsAppUrl(
                `Olá! Gostaria de agendar o serviço *${service.name}* (${service.price}) na Champions Barbearia.`
              );

              return (
                <div key={service.id} className="py-7 sm:py-8">
                  <button
                    type="button"
                    onClick={() => setActiveId(service.id)}
                    aria-pressed={isActive}
                    className="w-full text-left group focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-brand-bright rounded-sm"
                  >
                    <div className="flex items-baseline justify-between gap-4 mb-2.5">
                      <div className="flex items-baseline gap-3 sm:gap-4 min-w-0">
                        <span
                          className={`text-sm font-medium tabular-nums transition-colors duration-200 ${
                            isActive ? 'text-brand-bright' : 'text-ink-subtle'
                          }`}
                        >
                          {service.index}
                        </span>
                        <h3
                          className={`font-display text-2xl sm:text-3xl font-medium tracking-tight transition-colors duration-200 ${
                            isActive
                              ? 'text-ink'
                              : 'text-ink-muted group-hover:text-ink'
                          }`}
                        >
                          {service.name}
                        </h3>
                      </div>

                      <span className="font-display text-xl sm:text-2xl font-semibold tabular-nums text-ink whitespace-nowrap shrink-0">
                        {service.price}
                      </span>
                    </div>

                    <div className="pl-7 sm:pl-9 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <p className="text-sm sm:text-base text-ink-muted leading-relaxed max-w-[44ch]">
                        {service.description}
                      </p>
                    </div>
                  </button>

                  {/* Mobile inline image preview + direct action */}
                  <div className="pl-7 sm:pl-9 mt-4 flex flex-wrap items-center justify-between gap-4">
                    <span className="text-xs text-ink-subtle tabular-nums">
                      Duração média · {service.duration}
                    </span>
                    <a
                      href={serviceWaUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-brand-bright hover:text-ink transition-colors whitespace-nowrap shrink-0"
                    >
                      <span>Agendar {service.name}</span>
                      <ArrowUpRight className="w-3.5 h-3.5" aria-hidden="true" />
                    </a>
                  </div>

                  {/* On mobile/tablet (<lg), show crisp photo directly under active item */}
                  {isActive && (
                    <div className="lg:hidden mt-5 rounded-xl overflow-hidden border border-hairline aspect-[4/3] bg-surface">
                      <ResilientImage
                        src={service.image}
                        alt={service.imageAlt}
                        loading="lazy"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Right: Desktop Active Portrait Showcase */}
          <div className="hidden lg:flex lg:col-span-6">
            <div className="relative w-full min-h-[540px] rounded-xl overflow-hidden border border-hairline bg-surface">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeService.id}
                  initial={prefersReduced ? false : { opacity: 0, scale: 1.02 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={prefersReduced ? undefined : { opacity: 0 }}
                  transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                  className="absolute inset-0"
                >
                  <ResilientImage
                    src={activeService.image}
                    alt={activeService.imageAlt}
                    loading="lazy"
                    className="w-full h-full object-cover object-center"
                  />
                </motion.div>
              </AnimatePresence>

              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-canvas/90 via-canvas/25 to-transparent pointer-events-none"
              />

              <div className="absolute bottom-7 left-7 right-7 flex items-end justify-between gap-6">
                <div>
                  <p className="text-xs tracking-[0.14em] uppercase text-ink-muted mb-1.5 tabular-nums">
                    {activeService.index} · {activeService.duration}
                  </p>
                  <p className="font-display text-3xl font-semibold text-ink">
                    {activeService.name} —{' '}
                    <span className="tabular-nums">{activeService.price}</span>
                  </p>
                </div>

                <a
                  href={buildWhatsAppUrl(
                    `Olá! Gostaria de agendar *${activeService.name}* (${activeService.price}) na Champions Barbearia.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-ink bg-brand hover:bg-brand-hover rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-brand-bright"
                >
                  <MessageCircle className="w-4 h-4" aria-hidden="true" />
                  <span>Agendar agora</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
