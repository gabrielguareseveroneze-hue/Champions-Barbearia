export interface BarbershopService {
  id: string;
  index: string;
  name: string;
  price: string;
  priceValue: number;
  duration: string;
  description: string;
  image: string;
  imageAlt: string;
}

export interface GalleryPhoto {
  id: string;
  src: string;
  alt: string;
  caption: string;
  spanClass: string;
  aspectClass: string;
}

export interface BarbershopStat {
  value: string;
  label: string;
}

export const WHATSAPP_NUMBER = '5563992965167';
export const PHONE_DISPLAY = '(63) 99296-5167';
export const ADDRESS_FULL =
  'Em frente à Iparaty/Pardal - Av. Cônego João Lima, Jardim dos Ipês 2, Araguaína - TO, 77820-008';

export function buildWhatsAppUrl(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export const MAPS_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  'Av. Cônego João Lima, Jardim dos Ipês 2, Araguaína - TO, 77820-008'
)}`;

export const HERO_IMAGE = {
  src: '/assets/aistudio/image_f1aa64bc.png',
  alt: 'Fachada iluminada da Champions Barbearia à noite em Araguaína',
};

export const SERVICES: BarbershopService[] = [
  {
    id: 'corte-masculino',
    index: '01.',
    name: 'Corte Masculino',
    price: 'R$ 60',
    priceValue: 60,
    duration: '45 min',
    description:
      'Visagismo preciso, tesoura e degradê executados sob medida para o seu rosto e rotina.',
    image: '/assets/aistudio/image_decb5dbc.png',
    imageAlt: 'Barbeiro realizando corte de precisão na Champions Barbearia',
  },
  {
    id: 'barba',
    index: '02.',
    name: 'Barba',
    price: 'R$ 45',
    priceValue: 45,
    duration: '30 min',
    description:
      'Desenho limpo, acabamento com shaver de alta precisão e hidratação para a pele.',
    image: '/assets/aistudio/imagem_2026-11-17_151556268_0bfb7412.png',
    imageAlt: 'Acabamento detalhado de barba com shaver na Champions Barbearia',
  },
  {
    id: 'tratamento-capilar',
    index: '03.',
    name: 'Tratamento Capilar',
    price: 'R$ 80',
    priceValue: 80,
    duration: '40 min',
    description:
      'Lavatório reservado com higienização profunda, reconstrução dos fios e relaxamento.',
    image: '/assets/aistudio/imagem_2026-11-17_151501957_92bd2110.png',
    imageAlt: 'Área de lavatório e tratamento capilar da Champions Barbearia',
  },
];

export const STATS: BarbershopStat[] = [
  { value: '15+', label: 'Anos de experiência' },
  { value: '10.000+', label: 'Clientes atendidos' },
  { value: '5', label: 'Barbeiros especialistas' },
  { value: '4,9', label: 'Avaliação média' },
];

export const STORY_IMAGE = {
  src: '/assets/aistudio/imagem_2026-11-17_151524679_96f46f7a.png',
  alt: 'Barbeiros especialistas da Champions Barbearia realizando atendimento de precisão',
};

export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'fachada',
    src: '/assets/aistudio/image_f1aa64bc.png',
    alt: 'Fachada moderna e iluminada da Champions Barbearia em Araguaína',
    caption: 'Fachada · Jardim dos Ipês 2',
    spanClass: 'md:col-span-7',
    aspectClass: 'aspect-[16/10]',
  },
  {
    id: 'lavatorio',
    src: '/assets/aistudio/imagem_2026-11-17_151501957_92bd2110.png',
    alt: 'Lavatório sofisticado com poltronas pretas e iluminação direcionada',
    caption: 'Lavatório & Tratamento Capilar',
    spanClass: 'md:col-span-5',
    aspectClass: 'aspect-[4/3] md:aspect-auto md:h-full',
  },
  {
    id: 'equipe',
    src: '/assets/aistudio/imagem_2026-11-17_151524679_96f46f7a.png',
    alt: 'Dois barbeiros da Champions Barbearia cuidando dos detalhes do rosto do cliente',
    caption: 'Atendimento Especializado',
    spanClass: 'md:col-span-4',
    aspectClass: 'aspect-[4/5]',
  },
  {
    id: 'acabamento-barba',
    src: '/assets/aistudio/imagem_2026-11-17_151556268_0bfb7412.png',
    alt: 'Detalhe de acabamento rente de barba com shaver metálico',
    caption: 'Precisão no Acabamento',
    spanClass: 'md:col-span-4',
    aspectClass: 'aspect-[4/5]',
  },
  {
    id: 'corte-kids',
    src: '/assets/aistudio/image_decb5dbc.png',
    alt: 'Corte infantil com atenção e cuidado na cadeira da Champions Barbearia',
    caption: 'Estilo para Todas as Gerações',
    spanClass: 'md:col-span-4',
    aspectClass: 'aspect-[4/5]',
  },
];
