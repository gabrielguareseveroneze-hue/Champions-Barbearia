/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MotionConfig } from 'motion/react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { StoryGallerySection } from './components/StoryGallerySection';
import { ContactBookingSection } from './components/ContactBookingSection';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-dvh bg-canvas text-ink flex flex-col">
        <Navbar />
        <main className="flex-1">
          <HeroSection />
          <ServicesSection />
          <StoryGallerySection />
          <ContactBookingSection />
        </main>
        <Footer />
      </div>
    </MotionConfig>
  );
}
